import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const sb = SUPABASE_URL && SUPABASE_KEY ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const jobs=[
["Delivery Rider",120,12,10,1],["Shop Assistant",180,14,12,1],["Teacher",320,16,18,2],
["Nurse",500,18,25,3],["Software Developer",850,20,35,5],["Banking Officer",1200,22,45,7],["Investment Analyst",2500,25,70,10]];
const lands=[
["Madina Plot",12000,180],["Tema Plot",28000,420],["Spintex Plot",65000,1050],
["Osu Plot",180000,2900],["East Legon Plot",450000,7600],["Airport Residential Plot",900000,15000]];
const vehicles=[["Motorbike",9000,220],["Taxi",35000,900],["Hyundai Bus",160000,4200],["Tro-tro",240000,6200],["Delivery Van",190000,5100]];
const businesses=[["Waakye Spot",2500,55],["Barbershop",7000,150],["Car Wash",18000,420],["Provision Shop",30000,650],["Event Centre",85000,1900],["Logistics Company",250000,6200],["Hotel",900000,23000]];
const missions=[["first_shift","First Shift","Work 1 shift",1,1000],["landlord","Landlord","Buy 1 plot",1,2500],["business_owner","Business Owner","Buy 1 business",1,5000],["road_king","Road King","Own 1 vehicle",1,3000],["empire","Empire Builder","Own 3 businesses",3,25000]];
const money=n=>"GH₵"+Math.floor(n).toLocaleString();

let user=null, profile=null, assets=[];

async function load(){
  if(!sb){showSetup(); return;}
  const {data:{user:u}}=await sb.auth.getUser(); user=u;
  if(!user){showAuth(); return;}
  let p=await sb.from("profiles").select("*").eq("id",user.id).single();
  profile=p.data;
  let a=await sb.from("player_assets").select("*").eq("player_id",user.id).order("id");
  assets=a.data||[]; render();
}
async function signUp(){
  const username=document.querySelector("#username").value.trim()||"Player";
  const email=document.querySelector("#email").value.trim(), password=document.querySelector("#password").value;
  const {error}=await sb.auth.signUp({email,password,options:{data:{username}}});
  msg(error?error.message:"Account created. Check your email if confirmation is enabled.");
}
async function signIn(){
  const email=document.querySelector("#email").value.trim(), password=document.querySelector("#password").value;
  const {error}=await sb.auth.signInWithPassword({email,password});
  msg(error?error.message:"Signed in.");
  if(!error) await load();
}
async function signOut(){await sb.auth.signOut();location.reload()}
async function work(i){
  const j=jobs[i]; if(profile.level<j[4]||profile.energy<j[2])return;
  profile.cash+=j[1]; profile.energy-=j[2]; profile.xp+=j[3];
  if(profile.xp>=profile.level*100){profile.xp-=profile.level*100;profile.level++}
  await saveProfile();
}
async function buy(type,i){
  const list=type==="land"?lands:type==="vehicle"?vehicles:businesses, x=list[i];
  if(profile.cash<x[1])return;
  profile.cash-=x[1];
  assets.push({player_id:user.id,asset_type:type,asset_key:x[0],purchase_price:x[1],daily_income:x[2]});
  await sb.from("player_assets").insert(assets[assets.length-1]);
  await saveProfile(); await load();
}
async function saveProfile(){await sb.from("profiles").update({cash:profile.cash,energy:profile.energy,health:profile.health,level:profile.level,xp:profile.xp}).eq("id",user.id);render()}
function msg(t){document.querySelector("#message").textContent=t}
function showSetup(){document.body.innerHTML=`<main class="box"><h1>Accra Life</h1><p>Connect Supabase first.</p><p>Copy <b>.env.example</b> to <b>.env</b>, add your project URL and publishable key, then run the app.</p></main>`}
function showAuth(){document.body.innerHTML=`<main class="box"><h1>🇬🇭 Accra Life</h1><p>Create an account or sign in.</p><input id="username" placeholder="Username"><input id="email" placeholder="Email"><input id="password" type="password" placeholder="Password"><button onclick="signUp()">Create account</button><button onclick="signIn()">Sign in</button><p id="message"></p></main>`}
function render(){
const daily=assets.reduce((n,a)=>n+a.daily_income,0);
document.body.innerHTML=`<header><b>ACCRA LIFE</b><span>${money(profile.cash)}</span></header>
<nav><button onclick="home()">🏠 Home</button><button onclick="jobsView()">💼 Jobs</button><button onclick="assetsView('land')">🏠 Property</button><button onclick="assetsView('business')">🏪 Business</button><button onclick="assetsView('vehicle')">🚗 Garage</button><button onclick="signOut()">↪ Sign out</button></nav>
<main><section class="hero"><h1>Welcome, ${profile.username}</h1><p>Level ${profile.level} · Daily passive income ${money(daily)}</p></section><div id="view"></div></main>`;
home();
}
function home(){document.querySelector("#view").innerHTML=`<div class="grid"><div class="card"><h2>💰 Cash</h2><b>${money(profile.cash)}</b></div><div class="card"><h2>⚡ Energy</h2><b>${profile.energy}%</b><button onclick="rest()">Rest +35</button></div><div class="card"><h2>📈 XP</h2><b>${profile.xp}/${profile.level*100}</b></div></div><div class="card"><h2>Build your empire</h2><p>Work, buy property, own vehicles and build businesses across Accra.</p></div>`}
function jobsView(){document.querySelector("#view").innerHTML=`<h2>Jobs</h2>${jobs.map((j,i)=>`<div class="card row"><div><b>${j[0]}</b><p>${money(j[1])} per shift · ${j[2]} energy · Level ${j[4]}+</p></div><button onclick="work(${i})" ${profile.level<j[4]||profile.energy<j[2]?"disabled":""}>Work</button></div>`).join("")}`}
function assetsView(type){const list=type==="land"?lands:type==="vehicle"?vehicles:businesses;document.querySelector("#view").innerHTML=`<h2>${type==="land"?"Property":type==="vehicle"?"Garage":"Businesses"}</h2><div class="grid">${list.map((x,i)=>`<div class="card"><h3>${x[0]}</h3><p>${money(x[1])}</p><p>+${money(x[2])}/day</p><button onclick="buy('${type}',${i})" ${profile.cash<x[1]?"disabled":""}>Buy</button></div>`).join("")}</div>`}
async function rest(){profile.energy=Math.min(100,profile.energy+35);await saveProfile()}
load();
